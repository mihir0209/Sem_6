    <?php
    $conn = mysqli_connect("localhost","root","Mihir0209","cookie");
     
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
    ?>